import csv
from operator import itemgetter

def get_top10_station(tashu_dict, station_dict):

	tashu_file = open('tashu.csv','r')
	tashu=csv.DictReader(tashu_file)
	station_file = open('station.csv','r')
	station=csv.DictReader(station_file)

	matrix =[0]*250
	place =[0]*250
	for rent in tashu :
		matrix[int(rent['RENT_STATION'])]=matrix[int(rent['RENT_STATION'])]+1
		matrix[int(rent['RETURN_STATION'])]=matrix[int(rent['RETURN_STATION'])]+1
	for pl in station :
		place[int(pl['번호'])]=pl['명칭']

	i=1
	j=1
	max=int(matrix[1])
	station=1
	temp=0
	resultCount=[0]*10
	resultStation=[0]*10
	result=[]
	for i in range(10) :
		for j in range(250) : 
			if max<matrix[j] :
				max=int(matrix[j])
				resultCount[i]=max
				resultStation[i]=j
		matrix[resultStation[i]]=0;
		max=matrix[i];
		result.append([place[resultStation[i]],str(resultStation[i]),resultCount[i]])

	print(result)
	tashu_file.close()
	station_file.close()
	return result
 #   [역할]
 #   정류장 Top10 출력하기
 #   대여 정류장과 반납정류장을 합한 총 사용빈도수 Top10

 #   [입력]
 #   tashu_dict : csv.DictReader 형태의 타슈대여정보
 #   station_dict : csv.DictReader 형태의 정류장 정보

 #   [출력]
 #   Top10 정류장 리스트
 #   ex.) [[정류장 이름1, 정류장 번호1, 정류장1 count], [정류장 이름2, 정류장 번호2, 정류장2 count], .....] 형태
     
def get_top10_trace(tashu_dict, station_dict):
    """
    [역할]
    경로 Top10 출력하기
    (대여정류장, 반납정류장)의 빈도수 Top10

    [입력]
    tashu_dict : csv.DictReader 형태의 타슈대여정보
    station_dict : csv.DictReader 형태의 정류장 정보

    [출력]
    Top10 경로 리스트
    ex.) [[출발정류장 이름1, 출발정류장 번호1, 반납정류장 이름1,
        반납정류장 번호2, 경로 count], [출발정류장 이름2, 출발정류장 번호2,
        반납정류장 이름2,  반납정류장 번호2, 경로count2], .....] 형태
    """
    return None
